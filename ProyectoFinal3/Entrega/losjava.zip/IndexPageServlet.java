import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class IndexPageServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head>");
        out.println("<title>AmazingStore</title>");
        out.println("<link rel='stylesheet' href='styles.css'>");
        out.println("</head>");
        out.println("<body>");

        out.println("<header class='header'>");
        out.println("<div class='logo'>AmazingStore</div>");
        out.println("<div class='user-icon'>👤</div>");
        out.println("</header>");

        out.println("<main class='container'>");

        try (Connection con = DBConnection.getConnection()) {

            PreparedStatement ps = con.prepareStatement("SELECT * FROM producto");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                out.println("<div class='card'>");

                out.println("<img src='" + rs.getString("imagen") + "' width='200'>");
                out.println("<h3>" + rs.getString("nombre") + "</h3>");
                out.println("<p>" + rs.getString("descripcion") + "</p>");
                out.println("<p class='price'>€" + rs.getDouble("precio") + "</p>");

                out.println("<form action='addToCart' method='post'>");
                out.println("<select name='cantidad'>");
                for (int i = 1; i <= 5; i++) {
                    out.println("<option value='" + i + "'>" + i + "</option>");
                }
                out.println("</select>");

                out.println("<input type='hidden' name='idProducto' value='" +
                        rs.getInt("id_producto") + "'>");

                out.println("<input type='submit' value='Add to cart'>");
                out.println("</form>");

                out.println("</div>");
            }

        } catch (Exception e) {
            out.println("<p>Error: " + e.getMessage() + "</p>");
        }

        out.println("<form action='cart' method='get'>");
        out.println("<input type='submit' value='Finalizar compra'>");
        out.println("</form>");

        out.println("</main>");
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirigir POST al GET para evitar duplicar código
        doGet(request, response);
    }
}

