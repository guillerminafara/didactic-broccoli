import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ConfirmarCompraServlet extends HttpServlet {

    protected void doPost(HttpServletRequest peticion, HttpServletResponse respuesta)
            throws ServletException, IOException {

        respuesta.setContentType("text/html;charset=UTF-8");
        PrintWriter out = respuesta.getWriter();

        HttpSession session = peticion.getSession(false);

        if (session == null) {
            out.println("<h2>Sesión no válida</h2>");
            return;
        }

        List<ItemCarrito> carrito =
            (List<ItemCarrito>) session.getAttribute("carrito");

        if (carrito == null || carrito.isEmpty()) {
            out.println("<h2>No hay productos en el carrito</h2>");
            return;
        }

        // Obtener usuario desde cookie
        int idUsuario = -1;
        Cookie[] cookies = peticion.getCookies();

        if (cookies != null) {
            for (Cookie c : cookies) {
                if ("id_usuario".equals(c.getName())) {
                    try {
                        idUsuario = Integer.parseInt(c.getValue());
                    } catch (NumberFormatException e) {
                        idUsuario = -1;
                    }
                    break;
                }
            }
        }

        if (idUsuario == -1) {
            out.println("<h2>Error: usuario no identificado</h2>");
            return;
        }

        double total = 0;
        for (ItemCarrito item : carrito) {
            total += item.getPrecio() * item.getCantidad();
        }

        Connection con = null;
        PreparedStatement psCompra = null;
        PreparedStatement psDetalle = null;

        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false); // 🔴 IMPORTANTE para rollback

            // Insertar compra
            String sqlCompra =
                "INSERT INTO compra (id_usuario, fecha_compra, total) VALUES (?,?,?)";

            psCompra = con.prepareStatement(sqlCompra, Statement.RETURN_GENERATED_KEYS);
            psCompra.setInt(1, idUsuario);
            psCompra.setDate(2, new Date(System.currentTimeMillis())); // ✔ Date correcta
            psCompra.setDouble(3, total);
            psCompra.executeUpdate();

            ResultSet rs = psCompra.getGeneratedKeys();
            int idCompra = 0;

            if (rs.next()) {
                idCompra = rs.getInt(1);
            }
            rs.close();

            // Insertar detalle compra
            String sqlDetalle =
                "INSERT INTO compra_producto (id_producto, id_compra, cantidad, precio_unitario, subtotal) VALUES (?,?,?,?,?)";

            psDetalle = con.prepareStatement(sqlDetalle);

            for (ItemCarrito item : carrito) {
                double subtotal = item.getPrecio() * item.getCantidad();

                psDetalle.setInt(1, item.getIdProducto());
                psDetalle.setInt(2, idCompra);
                psDetalle.setInt(3, item.getCantidad());
                psDetalle.setDouble(4, item.getPrecio());
                psDetalle.setDouble(5, subtotal);
                psDetalle.executeUpdate();
            }

            con.commit(); // ✔ confirmar todo

            session.removeAttribute("carrito");

            // HTML respuesta
            out.println("<!DOCTYPE html>");
            out.println("<html lang='es'>");
            out.println("<head>");
            out.println("<meta charset='UTF-8'>");
            out.println("<title>Pedido confirmado</title>");
            out.println("<style>");
            out.println("body{font-family:Arial;text-align:center;background:#EAEDED;}");
            out.println(".box{margin:100px auto;width:400px;padding:30px;background:white;border-radius:8px;}");
            out.println(".ok{color:green;font-size:22px;}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");

            out.println("<div class='box'>");
            out.println("<h2 class='ok'>¡Gracias por tu compra!</h2>");
            out.println("<p>Tu pedido ha sido registrado correctamente.</p>");
            out.println("<p><strong>Número de seguimiento:</strong></p>");
            out.println("<h1>" + idCompra + "</h1>");
            out.println("<a href='paginaPrincipal'>Volver a la tienda</a>");
            out.println("</div>");

            out.println("</body>");
            out.println("</html>");

        } catch (Exception e) {
            try {
                if (con != null)
                    con.rollback();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            out.println("<h2>Error al registrar la compra</h2>");
            out.println("<pre>" + e.getMessage() + "</pre>");

        } finally {
            try {
                if (psDetalle != null)
                    psDetalle.close();
                if (psCompra != null)
                    psCompra.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

