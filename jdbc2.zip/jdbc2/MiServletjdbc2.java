import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;


public class MiServlet extends HttpServlet
{
    public void doGet(HttpServletRequest peticion, HttpServletResponse respuesta)
    throws ServletException, IOException
    {
        respuesta.setContentType("text/html");
        PrintWriter salida = respuesta.getWriter();
        String titulo = "Conexión JDBC a MySQL";
        salida.println ("<TITLE>"+titulo+"</TITLE>\n");
        salida.println ("<BODY BGCOLOR=\"#FDF5E6\">\n");
        salida.println ("<H1 ALIGN=CENTER>"+titulo+"</H1>\n\n");
       
        try
        {

           //Class.forName("org.mariadb.jdbc.Driver");
            String SourceURL = "jdbc:mysql://localhost/bdprueba?allowPublicKeyRetrieval=true&useSSL=false";
            String user = "alumno";
            String password = "mipassword";
           
            Connection miconexion;
// establish the connection to database
            miconexion = DriverManager.getConnection(SourceURL, user, password);

            Statement misentencia;
            ResultSet misresultados;
            //create sql statement 
            misentencia=miconexion.createStatement(); 
            //get the employee whose DNI is equals to "22222222"
            misresultados=misentencia.executeQuery ("SELECT * FROM empleados where DNI = 22222222");
           //print the table header
            salida.println(
                "<TABLE BORDER=1 ALIGN=CENTER>\n"+
                "<TR BGCOLOR=\"#FFAD00\">\n"+
                "<TH>DNI<TH>Nombre<TH>Sueldo");
           
            while (misresultados.next())
            {//fill the table
                salida.println(
                    "<TR><TD>"+
                    misresultados.getInt("DNI")+"\n<TD>"+
                    misresultados.getString("nombre")+"\n<TD>"+
                    misresultados.getFloat("sueldo"));
            }
            //print the table
            salida.println("</TABLE></BODY></HTML>");
            miconexion.close();
        }
        catch (SQLException sqle)
        {
            salida.println(sqle);
            salida.println("</BODY></HTML>");
        }
    }
}
